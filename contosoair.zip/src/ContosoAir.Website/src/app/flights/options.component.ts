import { Component } from '@angular/core';

@Component({
    selector: 'options',
    templateUrl: './options.component.html'
})
export class OptionsComponent{}
