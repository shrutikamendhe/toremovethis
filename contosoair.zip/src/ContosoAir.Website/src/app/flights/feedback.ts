export interface Feedback {
    Poor_Feedbacks: string,
    Average_Feedbacks: string,
    Good_Feedbacks: string
}