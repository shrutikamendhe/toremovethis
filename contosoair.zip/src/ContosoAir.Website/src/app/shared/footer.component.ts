import { Component } from '@angular/core';

@Component({
    selector: 'app-footer',
    providers: [],
    templateUrl: './footer.component.html'
})
export class FooterComponent {
    name: string;

    constructor() {}

}
