﻿module.exports = {
    none: 0,
    checkInAvailable: 1,
    delayedFlight: 2,
    giveFeedback: 3
}
